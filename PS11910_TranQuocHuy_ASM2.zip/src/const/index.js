export const SET_CAT_TO_STATE = "SET_CAT_TO_STATE";
export const ADD_NEW_CAT = "ADD_NEW_CAT";
export const EDIT_CAT = "EDIT_CAT";
export const REMOVE_CAT = "REMOVE_CAT";

export const ADD_NEW_PRO = "ADD_NEW_PRO";
export const EDIT_PRO = "EDIT_PRO";
export const REMOVE_PRO = "REMOVE_PRO";


export const SET_PRO_TO_STORE = "SET_PRO_TO_STORE";
export const ADD_NEW_CART = "ADD_NEW_CART";
export const EDIT_CART = "EDIT_CART";
export const REMOVE_CART = "REMOVE_CART";