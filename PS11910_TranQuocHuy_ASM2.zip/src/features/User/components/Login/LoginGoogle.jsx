// import React from 'react';
// import ReactDOM from 'react-dom';
// import GoogleLogin from 'react-google-login';
// import { GoogleLogin } from 'react-google-login';
// const responseGoogle = (response) => {
//     console.log(response);
// }
// ReactDOM.render(
//     <GoogleLogin
//         clientId="267514984177-9jmq7a1a45i4dug7b8snh11nqgtu34um.apps.googleusercontent.com"
//         buttonText="Login"
//         onSuccess={responseGoogle}
//         onFailure={responseGoogle}
//         cookiePolicy={'single_host_origin'}
//         isSignedIn={true}
//     />,
//     document.getElementById('googleButton')
// );