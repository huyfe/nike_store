import React from 'react';
import PropTypes from 'prop-types';
import { Col, Row } from 'react-bootstrap';
import Login from '../components/Login/Login';

LoginPage.propTypes = {

};

function LoginPage(props) {
    return (
        <Login />
    );
}

export default LoginPage;