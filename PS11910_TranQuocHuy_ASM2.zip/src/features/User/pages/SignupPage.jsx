import React from 'react';
import PropTypes from 'prop-types';

SignupPage.propTypes = {

};

function SignupPage(props) {
    return (
        <div>

        </div>
    );
}

export default SignupPage;